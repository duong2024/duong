# Frontier Chain UI

This is the [vuejs](https://vuejs.org/) user inteface to Frontier Chain.

It provides UI components including login, and a template for you to do additonal development.

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
